<?php 
include('include/sidebar.php');
include('include/doctorregstyle.php'); 
include('include/header.php'); 
?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Doctor Registration Form</h2>
    <form action="doctorregconn.php" method="POST" id="registrationForm">
        <div class="row g-3">
            <!-- Wallet Address Input (Manual Entry) -->
            <div class="col-md-6">
                <label for="walletAddress" class="form-label">Wallet Address</label>
                <input type="text" class="form-control" id="walletAddress" name="walletAddress" required>
            </div>

            <div class="col-md-6">
                <label for="fullName" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="fullName" name="fullName" required>
            </div>
            <div class="col-md-6">
                <label for="hospitalName" class="form-label">Hospital Name</label>
                <input type="text" class="form-control" id="hospitalName" name="hospitalName" required>
            </div>
            <div class="col-md-6">
                <label for="hospitalLocation" class="form-label">Hospital Location</label>
                <input type="text" class="form-control" id="hospitalLocation" name="hospitalLocation" required>
            </div>
            <div class="col-md-6">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" class="form-control" id="dob" name="dob" required>
            </div>
            <div class="col-md-6">
                <label for="gender" class="form-label">Gender</label>
                <select class="form-select" id="gender" name="gender" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="col-md-6">
                <label for="hhNumber" class="form-label">HH Number</label>
                <input type="text" class="form-control" id="hhNumber" name="hhNumber" required>
            </div>
            <div class="col-md-6">
                <label for="specialization" class="form-label">Specialization</label>
                <select class="form-select" id="specialization" name="specialization" required>
                    <option value="Dermatology">Dermatology</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Neurology">Neurology</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="department" class="form-label">Department</label>
                <select class="form-select" id="department" name="department" required>
                    <option value="Consultancy">Consultancy</option>
                    <option value="Surgery">Surgery</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="designation" class="form-label">Designation</label>
                <select class="form-select" id="designation" name="designation" required>
                    <option value="Doctor">Doctor</option>
                    <option value="Nurse">Nurse</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="experience" class="form-label">Work Experience</label>
                <input type="number" class="form-control" id="experience" name="experience" min="0" required>
            </div>
            <div class="col-md-6">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="col-md-6">
                <label for="confirmPassword" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
            </div>
        </div>
        <div class="mt-4 text-center">
            <!-- Submit Button -->
            <button type="submit" name="add" class="btn btn-primary" id="submitButton">Register</button>
        </div>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<?php 
include('include/footer.php');
?> 
