<?php include('include/header.php'); ?>
<style>
/* Custom styles for the login page */
.login-container {
    background-color: gray;
    border-radius: 15px;
    padding: 30px;
    width: 500px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.btn-custom {
    width: 100%;
    background-color: #007bff;
    color: white;
}

.btn-custom:hover {
    background-color: #0056b3;
}
</style>
</head>
<body class="bg-light">
    <div class="d-flex justify-content-center align-items-center vh-100">
        <div class="login-container">
            <h3 class="text-center mb-4">Login</h3>
            <!-- Login Form -->
            <form method="POST" action="loginconn.php">
                <!-- Email Input -->
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input 
                        type="email" 
                        class="form-control" 
                        id="email" 
                        name="email" 
                        placeholder="Enter your email" 
                        required>
                </div>
                <!-- Password Input -->
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input 
                        type="password" 
                        class="form-control" 
                        id="password" 
                        name="password" 
                        placeholder="Enter your password" 
                        required>
                </div>
                <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="patientlogin.php">Login as patient</a></li>
  </ol>
</nav>
                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary w-100">Login</button>
            </form>
            
      
            
        </div>
    </div>
    
</body>

<?php include('include/footer.php');
?>

