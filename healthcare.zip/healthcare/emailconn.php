<?php
// Include the PHPMailer autoloader
require 'vendor/autoload.php'; 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Start the session to store the code
session_start();

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the email (assuming the email comes from the user login or registration process)
    $email = 'castillano.khim12@gmail.com';  // Replace with dynamic email, e.g., from the session or database
    $code = rand(100000, 999999);  // Generate a random 6-digit code

    // Store the verification code in the session for later comparison
    $_SESSION['verification_code'] = $code;

    // Create an instance of PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();  
        $mail->Host = 'smtp.example.com';  
        $mail->SMTPAuth = true;
        $mail->Username = 'your_email@example.com';  
        $mail->Password = 'your_password';  
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  
        $mail->Port = 587;  

        // Recipients
        $mail->setFrom('from@example.com', 'Verification');  
        $mail->addAddress($email);  

        // Content
        $mail->isHTML(true);  
        $mail->Subject = 'Your Verification Code';
        $mail->Body    = 'Your verification code is: <b>' . $code . '</b>';

        // Send the email
        $mail->send();

        // Redirect to the verification page where the user enters the code
        header('Location: verifycode.php');
        exit;

    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
