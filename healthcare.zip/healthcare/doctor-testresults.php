<?php 
include('include/doctorsidebar.php');
include('include/patientregstyle.php'); 
include('include/header.php'); 
include('dbconnection.php'); // Include the database connection

// Fetch data from the database
$query = "SELECT wallet_address, full_name, file_path FROM patient_records";
$result = $conn->query($query); // Execute the query

if (!$result) {
    die("Error executing query: " . $conn->error);
}
?>
<body class="bg-light">
    <div class="container mt-5">
        <h2 class="text-center mb-4">Test Result</h2>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Wallet Address</th>
                    <th>Full Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 1;
                while ($row = $result->fetch_assoc()) {
                    $wallet_address = htmlspecialchars($row['wallet_address']);
                    $full_name = htmlspecialchars($row['full_name']);
                    $filePath = htmlspecialchars($row['file_path']); // Path to the user's file
                    echo "<tr>
                        <td>{$counter}</td>
                        <td>{$wallet_address}</td>
                        <td>{$full_name}</td>
                        <td>
                            <button 
                                class='btn btn-primary view-btn' 
                                data-bs-toggle='modal' 
                                data-bs-target='#fileModal' 
                                data-file='{$filePath}'>View</button>
                        </td>
                    </tr>";
                    $counter++;
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- File Display Modal -->
    <div class="modal fade" id="fileModal" tabindex="-1" aria-labelledby="fileModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="fileModalLabel">View File</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <!-- File Viewer -->
                    <iframe id="fileViewer" src="" width="100%" height="500px" style="border: none;"></iframe>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JS -->
    <script>
        document.querySelectorAll('.view-btn').forEach(button => {
            button.addEventListener('click', function() {
                const file = this.getAttribute('data-file'); // Get the file from the data attribute
                document.getElementById('fileViewer').src = file; // Set iframe src to the file

                // Extract file name and set it as modal title
                const fileName = file.split('/').pop(); // Extract file name from the path
                document.getElementById('fileModalLabel').innerText = `Viewing: ${fileName}`;
            });
        });
    </script>
</body>
