<?php include('include/header.php'); 

session_start();  // Start the session to access verification code

// Check if the user has submitted the code
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_code = $_POST['code'];  // The code the user entered

    // Compare the user-submitted code with the one stored in the session
    if ($user_code == $_SESSION['verification_code']) {
        // Code is correct, login the user
        // You can skip storing email and fullname again if already in the session from previous login

        // Clear the verification code from the session (security purpose)
        unset($_SESSION['verification_code']);

        // Redirect the user to the patient records page (or wherever you want)
        echo '<script>alert("Verification successful!"); window.location.href = "patient-records.php";</script>';
    } else {
        // Code is incorrect
        echo '<script>alert("Invalid code. Please try again."); window.location.href = "email.php";</script>';
    }
}
?>

<style>
/* Custom styles for the login page */
.login-container {
    background-color: gray;composer show phpmailer/phpmailer
    border-radius: 15px;
    padding: 30px;
    width: 500px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.btn-custom {
    width: 100%;
    background-color: #007bff;
    color: white;
}

.btn-custom:hover {
    background-color: #0056b3;
}
</style>

</head>
<body class="bg-light">
    <div class="d-flex justify-content-center align-items-center vh-100">
        <div class="login-container">
            <h3 class="text-center mb-4">2 Step Verification</h3>
            <!-- Login Form -->
            <form method="POST" action="verifycode.php">  <!-- Change the action to verifycode.php -->
                <!-- Code Input -->
                <div class="mb-3">
                    <label for="code" class="form-label">Enter Code</label>
                    <input 
                        type="text" 
                        class="form-control" 
                        id="code" 
                        name="code" 
                        placeholder="Enter Code" 
                        required>
                </div>
           
                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary w-100">Submit</button>
            </form>
            
        </div>
    </div>
</body>
