<?php 
include('include/sidebar.php');
include('include/managepatientstyle.php'); 
include('dbconnection.php');
?>

<div class="container-1">
<form method="POST" action="Managepatientconn.php" class="form-border">
    <input type="hidden" id="id" name="id">
    <div class="mb-3">
        <input type="text" class="form-control-1" id="fname" name="fname" placeholder="First Name" required>
    </div>
    <div class="mb-3">
        <input type="text" class="form-control" id="lname" name="lname" placeholder="Surname" required>
    </div>
    <div class="mb-3">
        <input type="text" class="form-control" id="mname" name="mname" placeholder="Middle Name" required>
    </div>
    <div class="mb-3">
        <input type="number" class="form-control" id="age" name="age" placeholder="Age" required>
    </div>
    <div class="mb-3">
        <input type="text" class="form-control" id="gender" name="gender" placeholder="Gender" required>
    </div>
    <button type="submit" name="add" class="btn-1 btn-primary">Add patient</button>
    <button type="submit" name="update" class="btn-1 btn-primary">Update</button>
</form>
</div>

<div class="container-2">
    <table border="1" cellpadding="10" cellspacing="0" id="patientTable">
        <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Gender</th>
        </tr>

        <?php
        // Fetch data from the database
        $query = "SELECT id, fname, mname, lname, age, gender FROM patients";
        $result = $conn->query($query);

        // Check if there are any records
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr onclick='fillForm(this)' data-id='{$row['id']}' data-fname='{$row['fname']}' data-mname='{$row['mname']}' data-lname='{$row['lname']}' data-age='{$row['age']}' data-gender='{$row['gender']}'>";
                echo "<td>" . $row['fname'] . " " . $row['mname'] . " " . $row['lname'] . "</td>";
                echo "<td>" . $row['age'] . "</td>";
                echo "<td>" . $row['gender'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3'>No records found</td></tr>";
        }

        // Close the connection
        $conn->close();
        ?>
    </table>
</div>

<script>
function fillForm(row) {
    document.getElementById('id').value = row.getAttribute('data-id');
    document.getElementById('fname').value = row.getAttribute('data-fname');
    document.getElementById('lname').value = row.getAttribute('data-lname');
    document.getElementById('mname').value = row.getAttribute('data-mname');
    document.getElementById('age').value = row.getAttribute('data-age');
    document.getElementById('gender').value = row.getAttribute('data-gender');
}
</script>
