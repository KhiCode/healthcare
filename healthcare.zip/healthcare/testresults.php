<?php 
include('include/sidebar.php'); 
include('include/testresultsstyle.php'); 
include('dbconnection.php'); // Include database connection

// Initialize the search term
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';

// Determine the SQL query based on whether the search term is empty
if ($searchTerm === '') {
    // Fetch all records if search term is empty
    $sql = "SELECT * FROM patient";
    $stmt = $conn->prepare($sql);
} else {
    // Fetch filtered records if search term is provided
    $sql = "SELECT * FROM patient WHERE fullname LIKE ?";
    $stmt = $conn->prepare($sql);
    $likeSearchTerm = '%' . $searchTerm . '%';
    $stmt->bind_param('s', $likeSearchTerm);
}

// Execute the query
$stmt->execute();
$result = $stmt->get_result();

?>

<div class="container-1">
  <form class="row g-3" method="GET">
    <div class="col-auto">
      <input type="text" class="form-control" name="search" placeholder="Search by Full Name" value="<?php echo htmlspecialchars($searchTerm); ?>">
    </div>
    <div class="col-auto">
      <button type="submit" class="btn-1 btn-primary mb-3">Search</button>
    </div>
  </form>
</div>

<div class="container-2">
  <table>
    <tr>
      <th>Date</th>
      <th>Full Name</th>
      <th>Gender</th>
      <th>Blood</th>
    </tr>

    <?php
    // Check if there are any results and loop through them
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['date']) . "</td>
                    <td>" . htmlspecialchars($row['fullname']) . "</td>
                    <td>" . htmlspecialchars($row['gender']) . "</td>
                    <td>" . htmlspecialchars($row['blood']) . "</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No results found for \"" . htmlspecialchars($searchTerm) . "\"</td></tr>";
    }

    // Close the prepared statement
    $stmt->close();

    // Close the database connection
    $conn->close();
    ?>
  </table>
</div>
