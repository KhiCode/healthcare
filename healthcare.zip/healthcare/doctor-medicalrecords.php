<?php 
include('include/doctorsidebar.php'); 
include('include/medicalrecordstyle.php'); 
include('dbconnection.php');

// Capture the search inputs
$searchName = isset($_GET['searchName']) ? htmlspecialchars(trim($_GET['searchName'])) : '';
$searchwallet = isset($_GET['searchwallet']) ? htmlspecialchars(trim($_GET['searchwallet'])) : '';
$searchGender = isset($_GET['searchGender']) ? htmlspecialchars(trim($_GET['searchGender'])) : '';

// Check if the wallet column exists
$walletColumnExists = false;
$columnCheck = $conn->query("SHOW COLUMNS FROM patient LIKE 'wallet'");
if ($columnCheck->num_rows > 0) {
    $walletColumnExists = true;
}

// Build the SQL query
$sql = "SELECT fullname, gender";
if ($walletColumnExists) {
    $sql .= ", wallet";
}
$sql .= " FROM patient WHERE 1=1";
$params = [];
$types = "";

// Add conditions
if (!empty($searchName)) {
    $sql .= " AND fullname LIKE ?";
    $params[] = "%$searchName%";
    $types .= "s";
}
if ($walletColumnExists && !empty($searchwallet)) {
    $sql .= " AND wallet = ?";
    $params[] = $searchwallet;
    $types .= "s";
}
if (!empty($searchGender)) {
    $sql .= " AND gender LIKE ?";
    $params[] = "%$searchGender%";
    $types .= "s";
}

// Prepare and execute the query
$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!-- The rest of the HTML and PHP remains unchanged -->
<div class="container-1">
    <!-- Form to search for patient details -->
    <form method="GET">
        <input type="text" class="form-control-1" name="searchName" placeholder="Name" value="<?php echo $searchName; ?>">
        <input type="text" class="form-control-1" name="searchwallet" placeholder="Wallet Address" value="<?php echo $searchwallet; ?>">
        <input type="text" class="form-control-1" name="searchGender" placeholder="Gender" value="<?php echo $searchGender; ?>">
        <button type="submit" class="btn-1 btn-dark">Search</button>
        <button type="button" class="btn-1 btn-dark" onclick="location.href='doctor-createrecords.php'">Create Record</button>
    </form>
</div>

<!-- Container-2: Display search results -->
<div class="container-2">
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>Full Name</th>
            <th>Wallet Address</th>
            <th>Gender</th>
        </tr>

        <?php
        // Check if there are any results
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Ensure the wallet address is displayed correctly
                $wallet = !empty($row['wallet']) ? htmlspecialchars($row['wallet']) : 'N/A';
                echo "<tr class='clickable-row' 
                        data-name='" . htmlspecialchars($row['fullname']) . "' 
                        data-wallet='" . $wallet . "' 
                        data-gender='" . htmlspecialchars($row['gender']) . "'>
                        <td>" . htmlspecialchars($row['fullname']) . "</td>
                        <td>" . $wallet . "</td>
                        <td>" . htmlspecialchars($row['gender']) . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>No data found</td></tr>";
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
        ?>
    </table>
</div>

<script>
// JavaScript to handle table row click event and populate input fields
document.querySelectorAll('.clickable-row').forEach(row => {
    row.addEventListener('click', () => {
        const fullName = row.dataset.name;
        const wallet = row.dataset.wallet || 'N/A';
        const gender = row.dataset.gender;

        // Populate input fields
        document.querySelector('input[name="searchName"]').value = fullName;
        document.querySelector('input[name="searchwallet"]').value = wallet;
        document.querySelector('input[name="searchGender"]').value = gender;
    });
});
</script>
