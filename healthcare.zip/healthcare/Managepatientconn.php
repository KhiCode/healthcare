<?php
include('dbconnection.php'); // Adjust the path as needed
session_start();

// Check if connection to database is established
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Add a new patient
if (isset($_POST['add'])) {
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];

    // Use prepared statement to insert data
    $stmt = $conn->prepare("INSERT INTO patients (fname, mname, lname, age, gender) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $fname, $mname, $lname, $age, $gender);

    if ($stmt->execute()) {
        echo '<script>alert("Patient Added Successfully"); window.location.href = "managepatients.php";</script>';
    } else {
        echo '<script>alert("Error: Could not add patient. Please try again."); window.location.href = "managepatients.php";</script>';
    }

    $stmt->close();
}

// Update an existing patient
if (isset($_POST['update'])) {
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $id = $_POST['id'];
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];

        // Prepared statement to update data
        $stmt = $conn->prepare("UPDATE patients SET fname=?, mname=?, lname=?, age=?, gender=? WHERE id=?");
        $stmt->bind_param("sssssi", $fname, $mname, $lname, $age, $gender, $id);

        if ($stmt->execute()) {
            echo '<script>alert("Patient Updated Successfully"); window.location.href = "managepatients.php";</script>';
        } else {
            echo '<script>alert("Error: Could not update patient. Please try again."); window.location.href = "managepatients.php";</script>';
        }

        $stmt->close();
    } else {
        echo '<script>alert("Error: Patient ID is missing."); window.location.href = "managepatients.php";</script>';
    }
}

$conn->close();
?>
