<?php 
include('include/doctorsidebar.php'); 
include('include/createrecordstyle.php'); 
include('dbconnection.php'); // Ensure you have a proper database connection

// Capture the search inputs
$searchName = isset($_GET['searchName']) ? $_GET['searchName'] : '';
$searchWallet = isset($_GET['searchWallet']) ? $_GET['searchWallet'] : ''; // Changed to search wallet address

// Build the SQL query with dynamic filters
$sql = "SELECT * FROM patient WHERE 1=1";

// Add conditions based on input fields
if (!empty($searchName)) {
    $sql .= " AND fullname LIKE '%$searchName%'";
}
if (!empty($searchWallet)) {
    $sql .= " AND wallet_address LIKE '%$searchWallet%'"; // Wallet-based search
}

$result = $conn->query($sql);

// Check if the form to add a record is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addRecord'])) {
    $walletAddress = $_POST['walletAddress'];
    $patientName = $_POST['patientName'];
    $doctorName = $_POST['doctorName'];
    $diagnosis = $_POST['diagnosis'];
    $prescription = $_POST['prescription'];

    // Validate inputs (basic validation for demonstration)
    if (!empty($walletAddress) && !empty($patientName) && !empty($doctorName) && !empty($diagnosis) && !empty($prescription)) {
        // Insert the new record into the database
        $insertSql = "INSERT INTO patient (wallet_address, fullname, doctor_name, diagnosis, prescription) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param('sssss', $walletAddress, $patientName, $doctorName, $diagnosis, $prescription);

        if ($stmt->execute()) {
            echo "<p class='success-msg'>Record added successfully!</p>";
        } else {
            echo "<p class='error-msg'>Error adding record: " . $conn->error . "</p>";
        }

        $stmt->close();
    } else {
        echo "<p class='error-msg'>Please fill in all fields.</p>";
    }
}
?>

<div class="container-1">
    <!-- Form to search for patient details -->
    <form method="GET">
        <input type="text" class="form-control-1" name="searchName" placeholder="Name" value="<?php echo htmlspecialchars($searchName); ?>">
        <input type="text" class="form-control-1" name="searchWallet" placeholder="Wallet Address" value="<?php echo htmlspecialchars($searchWallet); ?>">
        <button type="submit" class="btn-1 btn-dark">Search</button>
        <button type="button" class="btn-1 btn-dark" onclick="location.href='doctor-createrecords.php'">Create Record</button>
    </form>
</div>

<!-- Container-2: Add new record and display search results -->
<div class="container-2">
    <form id="registrationForm" action="doctor-createrecordconn.php" method="POST" enctype="multipart/form-data">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="wallet" class="form-label">Wallet Address</label>
                <input type="text" class="form-control" id="wallet" name="wallet" required>
            </div>
            <div class="col-md-6">
                <label for="fullName" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="fullName" name="fullName" required>
            </div>
            <div class="col-md-6">
                <label for="diagnostics" class="form-label">Diagnostics</label>
                <input type="text" class="form-control" id="diagnostics" name="diagnostics" required>
            </div>
            <div class="col-md-6">
                <label for="prescription" class="form-label">Prescription</label>
                <input type="text" class="form-control" id="prescription" name="Prescription" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Upload file</label>
                <input type="file" class="form-control" id="inputFile02" name="image">
            </div>
            <div class="mt-4 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
</div>
