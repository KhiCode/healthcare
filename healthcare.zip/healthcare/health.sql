-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2024 at 03:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctorID` int(11) NOT NULL,
  `wallet` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `hospital` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `hnumber` int(11) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `experience` int(11) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctorID`, `wallet`, `fullname`, `hospital`, `location`, `date`, `gender`, `email`, `hnumber`, `specialization`, `department`, `designation`, `experience`, `password`) VALUES
(9, '0xbCA3F99CB9686b493e1217aB9045E64ae72EC1f5', 'a', 'a', 'a', '2024-11-02', 'Female', 'a@gmail.com', 123, 'Dermatology', 'Consultancy', 'Doctor', 2, '$2y$10$6H207O3mkyjZbuJI/EdndOFKbVH7yvNiulAfrtMbh2NcfnGoqxtdC'),
(10, '0xbCA3F99CB9686b493e1217aB9045E64ae72EC1f5', 'khem', 'adelfa', 'polomolok', '2024-11-01', 'Male', 'doctor@gmail.com', 123, 'Dermatology', 'Consultancy', 'Doctor', 2, '$2y$10$dYWo9GSbQNY8txwp/vJGKuXK0L3yfDs7KnSDwmt9UwX3MsCSb9Nhi'),
(11, 'admin', 'admin', 'admin', 'admin', '2024-11-01', 'Female', 'admin@gmail.com', 123, 'Dermatology', 'Consultancy', 'Doctor', 2, '$2y$10$e6Hbjyd5J6kjT91hxxL4X.ruN9xqqE89XJTh9zPhrTPcecuUv2XKu');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patientID` int(11) NOT NULL,
  `wallet` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `blood` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `hhnumber` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirmpass` varchar(255) NOT NULL,
  `walletaddress` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patientID`, `wallet`, `fullname`, `date`, `gender`, `blood`, `address`, `hhnumber`, `email`, `password`, `confirmpass`, `walletaddress`) VALUES
(3, '0', 'a', '2024-11-02', 'Male', 'A+', 'a', 0, 'as@gmail.com', 'a', '', NULL),
(4, '0xbca3f99cb9686b493e1217ab9045e64ae72ec1f5', 'a', '2024-11-02', 'Male', 'A+', 'a', 12, 'ab@gmail.com', '$2y$10$TNu9BB02D5fK6sRA4WG0GuAXTyxrDhVq7v3fyvDhAMRIY6mjSkYB2', '', NULL),
(5, '0xbca3f99cb9686b493e1217ab9045e64ae72ec1f5', 'khim', '2024-11-01', 'Male', 'A+', 'polomolok', 123, 'patient@gmail.com', '$2y$10$BnBz4ihzs7zYSqfLzDSEZ.VUuiy3ic8ja8/bJbsqWa7hePKGx4DUi', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patient_doctor_access`
--

CREATE TABLE `patient_doctor_access` (
  `id` int(11) NOT NULL,
  `patientID` int(11) NOT NULL,
  `doctorID` int(11) NOT NULL,
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patient_records`
--

CREATE TABLE `patient_records` (
  `id` int(11) NOT NULL,
  `wallet_address` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `diagnostics` text NOT NULL,
  `prescription` text NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_records`
--

INSERT INTO `patient_records` (`id`, `wallet_address`, `full_name`, `diagnostics`, `prescription`, `file_path`, `created_at`) VALUES
(1, '0xbca3f99cb9686b493e1217ab9045e64ae72ec1', 'khim', 'Lung disorder', 'Amoxicillin', NULL, '2024-11-27 16:55:21'),
(2, '0xbca3f99cb9686b493e1217ab9045e64ae72ec1', 'khem', 'chronic bronchitis', 'loperamide', NULL, '2024-11-27 18:53:40'),
(3, 'a', 'a', 'a', 'a', NULL, '2024-11-27 18:57:07'),
(4, 'a', 'a', 'a', 'a', 'uploads/67476e31aa33e_th.jpg', '2024-11-27 19:08:33'),
(5, 'a', 'a', 'a', 'a', 'uploads/67476e6f46967_th.jpg', '2024-11-27 19:09:35'),
(6, 'b', 'b', 'a', 's', 'uploads/67476e870ce11_th.jpg', '2024-11-27 19:09:59'),
(7, 'asd', 'asd', 'asd', 'asd', 'uploads/6747d9f2269d0_th.jpg', '2024-11-28 02:48:18'),
(8, 'aaaaaaa', 'aaaaaaaa', 'aaaaaaaa', 'aaaa', 'uploads/6747da48d7aed_th.jpg', '2024-11-28 02:49:44');

-- --------------------------------------------------------

--
-- Table structure for table `uploaded_files`
--

CREATE TABLE `uploaded_files` (
  `id` int(11) NOT NULL,
  `patientID` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctorID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patientID`);

--
-- Indexes for table `patient_doctor_access`
--
ALTER TABLE `patient_doctor_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_patient` (`patientID`),
  ADD KEY `fk_doctor` (`doctorID`);

--
-- Indexes for table `patient_records`
--
ALTER TABLE `patient_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploaded_files`
--
ALTER TABLE `uploaded_files`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doctorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patient_doctor_access`
--
ALTER TABLE `patient_doctor_access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient_records`
--
ALTER TABLE `patient_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `uploaded_files`
--
ALTER TABLE `uploaded_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patient_doctor_access`
--
ALTER TABLE `patient_doctor_access`
  ADD CONSTRAINT `fk_doctor` FOREIGN KEY (`doctorID`) REFERENCES `doctor` (`doctorID`),
  ADD CONSTRAINT `fk_patient` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
