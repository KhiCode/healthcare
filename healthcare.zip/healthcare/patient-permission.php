<?php
include('include/patientsidebar.php');
include('include/patientregstyle.php');
include('include/header.php');
include('dbconnection.php');

// Start the session
session_start();

// Check if the patient is logged in by checking the session variable
if (!isset($_SESSION['patientID'])) {
    // Debugging: Output session variables to check if 'patientID' is set
    echo "<p>Session patientID is not set. Debugging:</p>";
    var_dump($_SESSION);  // This will display all session variables
    die("<p>Patient not logged in. Please log in to continue.</p>");
}

// Handle the form submission for wallet address
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the wallet address input from the form
    $walletAddress = trim($_POST['wallet_address']); // Trim whitespace

    // Check if the wallet address is empty
    if (empty($walletAddress)) {
        die("<p>Wallet address cannot be empty. Please provide a valid wallet address.</p>");
    }

    // Check if the wallet address exists in the doctor table
    $sql = "SELECT * FROM doctor WHERE BINARY wallet = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $walletAddress);

    // Check if the query executes successfully
    if (!$stmt->execute()) {
        die("<p>Query execution failed: " . $stmt->error . "</p>");
    }

    // Fetch the results
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Wallet address matches a doctor, grant access to the patient
        $doctor = $result->fetch_assoc();
        $doctorID = $doctor['doctorID']; // Doctor ID (from your 'doctor' table)

        // Assuming the logged-in patient ID is stored in the session
        $patientID = $_SESSION['patientID']; // Use the correct session variable

        // Check if the patient has already granted access
        $check_access_sql = "SELECT * FROM patient_doctor_access WHERE patientID = ? AND doctorID = ?";
        $check_stmt = $conn->prepare($check_access_sql);
        $check_stmt->bind_param('ii', $patientID, $doctorID);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows == 0) {
            // Insert access grant into the database
            $grant_access_sql = "INSERT INTO patient_doctor_access (patientID, doctorID) VALUES (?, ?)";
            $grant_stmt = $conn->prepare($grant_access_sql);
            $grant_stmt->bind_param('ii', $patientID, $doctorID);
            if ($grant_stmt->execute()) {
                // Optionally display a success message or perform other actions
            } else {
                // Handle error (if needed)
            }
        } else {
            echo '<script>alert("Doctor granted access.");</script>';
        }
    } else {
        echo '<script>alert("No doctor found with the provided wallet address."); </script>';
    }

    // Close statements and database connection
    $stmt->close();
    $conn->close();
}
?>

<style>
    /* Custom styles for the page */
    .login-container {
        background-color: gray;
        border-radius: 15px;
        padding: 30px;
        width: 500px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .btn-custom {
        width: 100%;
        background-color: #007bff;
        color: white;
    }

    .btn-custom:hover {
        background-color: #0056b3;
    }
</style>

<body class="bg-light">
    <div class="d-flex justify-content-center align-items-center vh-100">
        <div class="login-container">
            <h3 class="text-center mb-4">Grant Permission</h3>
            <!-- Form to enter wallet address -->
            <form method="POST">
                <div class="mb-3">
                    <label for="wallet_address" class="form-label">Wallet Address</label>
                    <input type="text" class="form-control" id="wallet_address" name="wallet_address" placeholder="Enter Wallet Address" required>
                </div>
                <button type="submit" class="btn btn-custom">Grant Permission</button>
            </form>
        </div>
    </div>
</body>
</html>
