<?php 
include('include/sidebar.php'); 
include('include/medicalrecordstyle.php'); 
include('dbconnection.php'); // Ensure you have a proper database connection

// Capture the search inputs
$searchName = isset($_GET['searchName']) ? $_GET['searchName'] : '';
$searchAge = isset($_GET['searchAge']) ? $_GET['searchAge'] : '';
$searchGender = isset($_GET['searchGender']) ? $_GET['searchGender'] : '';

// Build the SQL query with dynamic filters
$sql = "SELECT * FROM patient WHERE 1=1";

// Add conditions based on input fields
if (!empty($searchName)) {
    $sql .= " AND fullname LIKE '%$searchName%'";
}
if (!empty($searchAge)) {
    $sql .= " AND age = '$searchAge'";
}
if (!empty($searchGender)) {
    $sql .= " AND gender LIKE '%$searchGender%'";
}

$result = $conn->query($sql);
?>

<div class="container-1">
    <!-- Form to search for patient details -->
    <form method="GET">
        <input type="text" class="form-control-1" name="searchName" placeholder="Name" value="<?php echo htmlspecialchars($searchName); ?>">

        <input type="text" class="form-control-1" name="searchGender" placeholder="Gender" value="<?php echo htmlspecialchars($searchGender); ?>">
        <button type="submit" class="btn-1 btn-dark">Search</button>
        <button type="button" class="btn-1 btn-dark" onclick="location.href='medicalrecords.php'">Create Record</button>
    </form>
</div>

<!-- Container-2: Display search results -->
<div class="container-2">
    
</div>
