<?php
include('dbconnection.php'); // Include database connection file
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $walletAddress = mysqli_real_escape_string($conn, trim($_POST['wallet']));
    $fullName = mysqli_real_escape_string($conn, trim($_POST['fullName']));
    $diagnostics = mysqli_real_escape_string($conn, trim($_POST['diagnostics']));
    $prescription = mysqli_real_escape_string($conn, trim($_POST['Prescription']));

    // Initialize file path
    $filePath = null;

    // Handle file upload
    if (!empty($_FILES['image']['name'])) {
        $allowedMimeTypes = ["image/gif", "image/png", "image/jpeg", "application/pdf", "application/msword"];
        $fileMimeType = mime_content_type($_FILES['image']['tmp_name']);
        $fileName = basename($_FILES['image']['name']);
        $targetDirectory = "uploads/";
        $targetFile = $targetDirectory . uniqid() . "_" . $fileName;

        if (in_array($fileMimeType, $allowedMimeTypes)) {
            if (!is_dir($targetDirectory)) {
                mkdir($targetDirectory, 0755, true);
            }

            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                $filePath = $targetFile;
            } else {
                echo '<script>alert("File upload failed."); window.location.href = "createrecord.php";</script>';
                exit();
            }
        } else {
            echo '<script>alert("Invalid file type."); window.location.href = "createrecord.php";</script>';
            exit();
        }
    }

    // Insert data into the database
    $query = "INSERT INTO patient_records (wallet_address, full_name, diagnostics, prescription, file_path) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sssss', $walletAddress, $fullName, $diagnostics, $prescription, $filePath);

    if ($stmt->execute()) {
        echo '<script>alert("Record added successfully."); window.location.href = "doctor-createrecords.php";</script>';
    } else {
        echo '<script>alert("Error adding record: ' . $conn->error . '"); window.location.href = "doctor-createrecords.php";</script>';
    }

    $stmt->close();
}

$conn->close();
?>
