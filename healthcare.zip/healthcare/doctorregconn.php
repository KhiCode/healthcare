<?php
include('dbconnection.php'); // Adjust the path as needed
session_start();

// Check if connection to database is established
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Add a new doctor
if (isset($_POST['add'])) {
    // Capture the form data
    $wallet = mysqli_real_escape_string($conn, $_POST['walletAddress']);  // Manual Wallet Address
    $fullname = mysqli_real_escape_string($conn, $_POST['fullName']);
    $hospital = mysqli_real_escape_string($conn, $_POST['hospitalName']);
    $location = mysqli_real_escape_string($conn, $_POST['hospitalLocation']);
    $date = mysqli_real_escape_string($conn, $_POST['dob']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $hnumber = mysqli_real_escape_string($conn, $_POST['hhNumber']);
    $specialization = mysqli_real_escape_string($conn, $_POST['specialization']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    
    // Ensure $experience is an integer
    $experience = (int) $_POST['experience'];
    
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Check if the passwords match
    if ($password !== $confirmPassword) {
        echo '<script>alert("Passwords do not match!"); window.location.href = "doctorreg.php";</script>';
        exit();
    }

    // Hash the password before storing it
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Use prepared statement to insert data into the database
    $stmt = $conn->prepare("INSERT INTO doctor (wallet, fullname, hospital, location, date, gender, email, hnumber, specialization, department, designation, experience, password) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind the parameters with correct types
    $stmt->bind_param(
        "sssssssssssis",  
        $wallet,
        $fullname,
        $hospital,
        $location,
        $date,
        $gender,
        $email,
        $hnumber,
        $specialization,
        $department,
        $designation,
        $experience,     
        $hashedPassword
    );

    // Execute the statement
    if ($stmt->execute()) {
        echo '<script>alert("Doctor Added Successfully"); window.location.href = "doctorreg.php";</script>';
    } else {
        echo '<script>alert("Error: Could not add doctor. Please try again."); window.location.href = "doctorreg.php";</script>';
    }

    // Close the prepared statement
    $stmt->close();
}

$conn->close();
?> 
