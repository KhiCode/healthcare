<?php
include('dbconnection.php'); // Adjust the path as needed
session_start();

// Check if connection to database is established
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle the patient registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $wallet = mysqli_real_escape_string($conn, $_POST['wallet']);
    $fullname = mysqli_real_escape_string($conn, $_POST['fullName']);
    $date = mysqli_real_escape_string($conn, $_POST['dob']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $blood = mysqli_real_escape_string($conn, $_POST['specialization']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $hhnumber = mysqli_real_escape_string($conn, $_POST['hhNumber']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Check if passwords match
    if ($password !== $confirmPassword) {
        echo '<script>alert("Passwords do not match!"); window.location.href = "patientreg.php";</script>';
        exit();
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert the patient data
    $stmt = $conn->prepare("INSERT INTO patient (wallet, fullname, date, gender, blood, address, hhnumber, email, password) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("sssssssss", $wallet, $fullname, $date, $gender, $blood, $address, $hhnumber, $email, $hashedPassword);

    if ($stmt->execute()) {
        echo '<script>alert("Patient Registered Successfully!"); window.location.href = "patientreg.php";</script>';
    } else {
        echo '<script>alert("Error: Could not register patient. Please try again."); window.location.href = "patientreg.php";</script>';
    }

    $stmt->close();
}

$conn->close();
?>
