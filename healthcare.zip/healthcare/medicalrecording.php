<?php 
include('include/sidebar.php'); 
include('include/medicalrecordingstyle.php'); 
include('dbconnection.php'); // Ensure you have a proper database connection
?>

<div class="container-1">
    <!-- Form to search for patient details -->
    <input type="text" class="form-control-1" id="exampleFormControlInput1" name="searchName" placeholder="Name">
    <input type="text" class="form-control-1" id="exampleFormControlInput1" name="searchAge" placeholder="Age">
    <input type="text" class="form-control-1" id="exampleFormControlInput1" name="searchGender" placeholder="Gender">
    <button type="button" class="btn-1 btn-dark" onclick="location.href='page1.html'">Search</button>
</div>

<!-- Container-2: Example static content -->
<div class="container-2">
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>Date</th>
            <th>name</th>
            <th>insurance</th>
            <th>3</th>
            <th>4</th>
        </tr>
        <tr>
            <td>Data 1</td>
            <td>Data 2</td>
            <td>Data 3</td>
            <td>Data 2</td>
            <td>Data 3</td>
        </tr>
        <tr>
            <td>Data 4</td>
            <td>Data 5</td>
            <td>Data 6</td>
            <td>Data 2</td>
            <td>Data 3</td>
        </tr>
    </table>
</div>


<!-- Table to display patients -->
<div class="container-3">
    <table border="1" cellpadding="10" cellspacing="0" id="patientTable">
        <tr>
            <th>Firstname</th>
            <th>Surname</th>
            <th>Middlename</th>
            <th>Age</th>
            <th>Gender</th>
        </tr>

        <?php
        $query = "SELECT id, fname, lname, mname, age, gender FROM patients";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr onclick='openModal(this)' data-id='{$row['id']}' data-fname='{$row['fname']}' data-lname='{$row['lname']}' data-mname='{$row['mname']}' data-age='{$row['age']}' data-gender='{$row['gender']}'>";
                echo "<td>" . htmlspecialchars($row['fname']) . "</td>";
                echo "<td>" . htmlspecialchars($row['lname']) . "</td>";
                echo "<td>" . htmlspecialchars($row['mname']) . "</td>";
                echo "<td>" . htmlspecialchars($row['age']) . "</td>";
                echo "<td>" . htmlspecialchars($row['gender']) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No records found</td></tr>";
        }
        $conn->close();
        ?>
    </table>
</div>

<!-- Modal -->
<div id="patientModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <form method="POST" action="recordpatientdata.php">
            <input type="hidden" id="modal-id" name="id">
            <div>
                <label for="modal-fname">First Name:</label>
                <input type="text" id="modal-fname" name="fname" readonly>
            </div>
            <div>
                <label for="modal-lname">Last Name:</label>
                <input type="text" id="modal-lname" name="lname" readonly>
            </div>
            <div>
                <label for="modal-mname">Middle Name:</label>
                <input type="text" id="modal-mname" name="mname" readonly>
            </div>
            <div>
                <label for="modal-diagnosis">Diagnosis:</label>
                <input type="text" id="modal-diagnosis" name="diagnosis" placeholder="Enter diagnosis">
            </div>
            <div>
                <label for="modal-prescription">Prescription:</label>
                <input type="text" id="modal-prescription" name="prescription" placeholder="Enter prescription">
            </div>
            <button type="submit" name="record">Save Record</button>
        </form>
    </div>
</div>
<script>
    function openModal(row) {
        document.getElementById('modal-id').value = row.getAttribute('data-id');
        document.getElementById('modal-fname').value = row.getAttribute('data-fname');
        document.getElementById('modal-lname').value = row.getAttribute('data-lname');
        document.getElementById('modal-mname').value = row.getAttribute('data-mname');
        document.getElementById('patientModal').style.display = "block";
    }

    function closeModal() {
        document.getElementById('patientModal').style.display = "none";
    }
</script>