<?php
include('dbconnection.php');
session_start();

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user input and sanitize it
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password']; // Plain text password entered by the user

    // Prepare a query to find the user with the provided email
    $stmt = $conn->prepare("SELECT * FROM doctor WHERE email = ?");
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Fetch the hashed password from the database
        $hashedPassword = $user['password'];

        // Verify the entered password against the stored hashed password
        if (password_verify($password, $hashedPassword)) {
            // Password is correct
            $_SESSION['doctorID'] = $user['doctorID']; // Store user ID in session
            $_SESSION['full'] = $user['fullname']; // Optionally store user name
            $_SESSION['user_email'] = $email; // Store user email in session for future reference

            // Check if the user is an admin
            if ($email === 'admin@gmail.com') {
                echo '<script>alert("Admin Login Successful!"); window.location.href = "medicalrecords.php";</script>';
                exit();
            }

            // Redirect non-admin users to the medical records page
            echo '<script>alert("Login Successful!"); window.location.href = "doctor-profile.php";</script>';
        } else {
            // Password is incorrect
            echo '<script>alert("Invalid email or password. Please try again."); window.location.href = "login.php";</script>';
        }
    } else {
        // User not found
        echo '<script>alert("Invalid email or password. Please try again."); window.location.href = "login.php";</script>';
    }

    // Close the statement
    $stmt->close();
} else {
    // Redirect to the login page if accessed without form submission
    header("Location: login.php");
    exit();
}

// Close the database connection
$conn->close();
?>
