<?php 
include('include/sidebar.php'); 
include('include/medicalrecordstyle.php'); 
include('dbconnection.php'); // Ensure you have a proper database connection

// Capture the search inputs and sanitize them
$searchName = isset($_GET['searchName']) ? htmlspecialchars(trim($_GET['searchName'])) : '';
$searchAge = isset($_GET['searchAge']) ? htmlspecialchars(trim($_GET['searchAge'])) : '';
$searchGender = isset($_GET['searchGender']) ? htmlspecialchars(trim($_GET['searchGender'])) : '';

// Build the SQL query with dynamic filters using prepared statements
$sql = "SELECT * FROM patient WHERE 1=1";
$params = [];
$types = "";

// Add conditions based on input fields
if (!empty($searchName)) {
    $sql .= " AND fullname LIKE ?";
    $params[] = "%$searchName%";
    $types .= "s";
}
if (!empty($searchAge)) {
    $sql .= " AND age = ?";
    $params[] = $searchAge;
    $types .= "i";
}
if (!empty($searchGender)) {
    $sql .= " AND gender LIKE ?";
    $params[] = "%$searchGender%";
    $types .= "s";
}

// Prepare and execute the query
$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container-1">
    <!-- Form to search for patient details -->
    <form method="GET">
        <input type="text" class="form-control-1" name="searchName" placeholder="Name" value="<?php echo $searchName; ?>">
        <input type="text" class="form-control-1" name="searchAge" placeholder="Age" value="<?php echo $searchAge; ?>">
        <input type="text" class="form-control-1" name="searchGender" placeholder="Gender" value="<?php echo $searchGender; ?>">
        <button type="submit" class="btn-1 btn-dark">Search</button>
        
</div>

<!-- Container-2: Display search results -->
<div class="container-2">
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>Full Name</th>
            <th>Gender</th>
            <th>Blood Type</th>

        </tr>

        <?php
        // Check if there are any results
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr class='clickable-row' data-name='" . htmlspecialchars($row['fullname']) . "' data-gender='" . htmlspecialchars($row['gender']) . "'>
                        <td>" . htmlspecialchars($row['fullname']) . "</td>
                        <td>" . htmlspecialchars($row['gender']) . "</td>
                        <td>" . htmlspecialchars($row['blood']) . "</td>
                      
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No data found</td></tr>";
        }

        $stmt->close();
        $conn->close();
        ?>
    </table>
</div>

<script>
// JavaScript to handle table row click event and populate input fields
document.querySelectorAll('.clickable-row').forEach(row => {
    row.addEventListener('click', () => {
        const fullName = row.dataset.name;
        const age = row.dataset.age;
        const gender = row.dataset.gender;

        // Populate input fields
        document.querySelector('input[name="searchName"]').value = fullName;
        document.querySelector('input[name="searchAge"]').value = age;
        document.querySelector('input[name="searchGender"]').value = gender;
    });
});
</script>
