<?php

require 'vendor/autoload.php';

use Web3\Web3;

$infuraUrl = 'https://mainnet.infura.io/v3/c22c6db9baf449b3a2243dfc331e5f5c'; // Your Infura Project URL

// Initialize Web3 PHP client with Infura URL
$web3 = new Web3($infuraUrl);

// Get the underlying cURL handler
$provider = $web3->getProvider();

// Set custom cURL options
$provider->getClient()->setOpt(CURLOPT_TIMEOUT, 30);  // 30 seconds timeout
$provider->getClient()->setOpt(CURLOPT_CONNECTTIMEOUT, 30);  // 30 seconds connection timeout

// Send request to get the latest block number
$web3->eth->blockNumber(function ($err, $block) {
    if ($err !== null) {
        echo 'Error: ' . $err->getMessage();
        return;
    }

    // Convert the hexadecimal block number to decimal
    $blockNumber = hexdec($block);

    echo 'Latest Block Number (Decimal): ' . $blockNumber;
});
