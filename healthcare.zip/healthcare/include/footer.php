<script>
    // Check if MetaMask is installed
    if (typeof window.ethereum !== 'undefined') {
        const web3 = new Web3(window.ethereum);

        // Request access to the user's MetaMask accounts
        window.ethereum.enable().then(function(accounts) {
            console.log('MetaMask Account:', accounts[0]);

            // Store the address in a hidden form or pass it to PHP via AJAX
            document.getElementById("userWallet").value = accounts[0];  // Store in hidden input field
        }).catch(function(error) {
            console.error('User denied account access', error);
        });
    } else {
        console.log('Please install MetaMask!');
    }

    // Function to add health record to Ethereum (with Web3.js)
    function addHealthRecord(patientName, diagnosis) {
        const userAddress = document.getElementById("userWallet").value; // Get the wallet address from hidden field

        // Placeholder: Log record for now
        console.log('Adding Health Record:', patientName, diagnosis, 'for Wallet:', userAddress);

        // Here you can call your smart contract's addRecord method using Web3.js (as in Step 5)
    }
</script>