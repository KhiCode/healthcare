<style>
 .container{
    background-color: gray;
    border-radius: 15px;
    padding: 10px;
 }
 .btn{
    width: 300px;
    background-color: #f8f9fa; /* Slightly darker white for hover effect */
    color: black; /* Optional: Change text color on hover */
 }
</style>