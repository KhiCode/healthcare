<style>
    .container-1{
        background-color: gray;
        margin-top: 30px;
        width: 20%;
        height: 700px;
        margin-left: 250px;
        border-radius: 15px;

    }
    .container-2{
        background-color: gray;
        margin-top: -700px;
        width: 60%;
        height: 720px;
        margin-left: 700px;
        border-radius: 15px;  
    }
   
    .container-3{
        
        margin-top: -620px;
        width: 60%;
        height: 50px;
        margin-left: 700px;
        border-radius: 15px;  
    }
    .form-control{
    width: 90%; /* Adjusts the width */
    height: 50px; /* Adjusts the height */
    margin-top: 20px;
    margin-left: 20px;
    margin-bottom: 10px;
    font-size: 16px;
    border-radius: 5px;
    border: 3px solid #ccc;
  }
  .form-control-1{
    margin-top: 40px;
    width: 90%; /* Adjusts the width */
    height: 50px; /* Adjusts the height */

    margin-left: 20px;
    margin-bottom: 10px;
    font-size: 16px;
    border-radius: 5px;
    border: 3px solid #ccc;
  }
.btn-1{
    width: 350px;
    margin-left: 15px;
    margin-top: 15px;
    height: 50px;
    border-radius: 10px;
    background-color: black;
     -webkit-text-fill-color: white;
    
}
table {
    width: 100%;
    background-color: white;
    border-collapse: collapse;
    text-align: center;
    border-radius: 8px;
    overflow: hidden;
  }

  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    font-size: 14px;
    width: 10px;
  }

  th {
    background-color: #333;
    color: white;
  }
   
</style>