<?php include('include/header.php'); ?>

<style>
    /* Custom styles for the sidebar */
    #sidebar {
      height: 100vh;
      width: 200px;
      position: fixed;
      top: 0;
      left: 0;
      background-color: #343a40;
      padding-top: 20px;
    }

    #sidebar .btn {
      width: 100%;
      margin-bottom: 10px;
      color: black;
      margin-top: 30px;
      border-width: 10px;
      height: 80px;
      background-color: white;
      border-radius: 15px;
    }
    .a{
        margin-top: 50px;
    }
    #sidebar .btn-1 {
      width: 90%;
      margin-bottom: 10px;
      color: black;
      margin-top: 300px;
      margin-left: 5px;
      height: 40px;
    
      border-radius: 15px;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div id="sidebar" class="bg-dark">
    
    <button type="button" class="btn btn-dark" onclick="location.href='medicalrecords.php'">Medical Records</button>
    <button type="button" class="btn btn-dark" onclick="location.href='testresults.php'">Test Results</button>
    <button type="button" class="btn btn-dark" onclick="location.href='doctorreg.php'">Doctor Registration</button>
    <button type="button" class="btn btn-dark" onclick="location.href='patientreg.php'">Patient Registration</button>
    <button type="button" class="btn-1 btn-dark" onclick="location.href='login.php'">Log out</button>
  </div>

  