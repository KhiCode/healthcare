<style>
  body{
    background-color: #ccc;
  }
  .container-2{
        background-color: gray;
        margin-top: 20px;
        width: 70%;
        height: 700px;
        margin-left: 400px;
        border-radius: 15px;  
    }
.container-1{
       
        margin-top: 30px;
        width: 80%;
        height: 80px;
        margin-left: 700px;
        border-radius: 15px;  
    }
    .container-3{
        background-color: gray;
        margin-top: -820px;
        width: 25%;
        height: 800px;
        margin-left: 210px;
        border-radius: 15px;  
    }
    .form-control{
        margin-left: 420px;
        width: 60%;
        margin-top: 5px;
    }

  .form-control-1 {
    width: 90%; /* Full width within container */
    padding: 10px; /* Padding for better input sizing */
    margin-top: 10px;
    font-size: 16px; /* Adjust font size */
    border-radius: 8px; 
    margin-left: 20px;
  }

 

    .btn-1{
        width: 300px;
    margin-left: 170px;
    margin-top: 1px;
    height: 45px;
    border-radius: 10px;
    }
    .btn-2{
        width: 430px;
    margin-left: 20px;
    margin-top: 20px;
    height: 55px;
    border-radius: 10px;
    }
    table {
    width: 100%;
    background-color: white;
    border-collapse: collapse;
    text-align: center;
    border-radius: 8px;
    overflow: hidden;
  }

  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    font-size: 14px;
    width: 10px;
  }

  th {
    background-color: #333;
    color: white;
  }

 
</style>