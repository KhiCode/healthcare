<style>
       .container-1{
        background-color: yellow;
        margin-top: 40px;
        width: 20%;
        height: 820px;
        margin-left: 210px;
        border-radius: 15px;  
    }
    .container-2{
        background-color: red;
        margin-top: -820px;
        width: 50%;
        height: 820px;
        margin-left: 720px;
        border-radius: 15px; 
    }
    .container-3 {
    background-color: blue;
    width: 20%;
    height: 290px;
    border-radius: 15px;
    position: absolute;
    bottom: 70px; /* Position container-3 at the bottom of container-1 */
    left: 450px;
    transform: translateX(-50%);
    padding: 10px;
  }
  .form-control-1 {
    width: 90%; /* Adjusts the width */
    height: 50px; /* Adjusts the height */
    padding: 8px;
    margin-top: 50px;
    margin-left: 20px;
    font-size: 16px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  .btn-1{
    width: 90%;
    height: 50px;
    padding: 8px;
    margin-top: 50px;
    margin-left: 20px;
    border-radius: 15px;
    background-color: green;
    
  }

  /* Table styling */
  table {
    width: 100%;
    background-color: white;
    border-collapse: collapse;
    text-align: center;
    border-radius: 8px;
    overflow: hidden;
  }

  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    font-size: 14px;
  }

  th {
    background-color: #333;
    color: white;
  }
  
</style>