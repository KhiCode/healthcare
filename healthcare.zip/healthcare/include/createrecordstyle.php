<style>
       .container-1{
        background-color: gray;
        margin-top: 40px;
        width: 25%;
        height: 820px;
        margin-left: 210px;
        border-radius: 15px;  
    }
    .container-2{
        background-color: gray;
        margin-top: -820px;
        width: 60%;
        height: 820px;
        margin-left: 720px;
        border-radius: 15px; 
    }
    .container-3 {
    background-color: white;
    width: 24%;
    height: 290px;
    border-radius: 15px;
    position: absolute;
    bottom: 70px; /* Position container-3 at the bottom of container-1 */
    left: 450px;
    transform: translateX(-50%);
    padding: 10px;
  }
  .form-control-1 {
    width: 90%; /* Adjusts the width */
    height: 50px; /* Adjusts the height */
    padding: 8px;
    margin-top: 50px;
    margin-left: 20px;
    font-size: 16px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  .form-control {
    width: 90%; /* Adjusts the width */
    height: 50px; /* Adjusts the height */
    padding: 8px;

    margin-left: 20px;
    font-size: 16px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  .btn-1{
    width: 90%;
    height: 50px;
    padding: 8px;
    margin-top: 50px;
    margin-left: 20px;
    border-radius: 15px;
    background-color: black;
    -webkit-text-fill-color: white;
    
  }

  /* Table styling */
  table {
    width: 100%;
    background-color: white;
    border-collapse: collapse;
    text-align: center;
    border-radius: 8px;
    overflow: hidden;
  }

  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    font-size: 14px;
  }

  th {
    background-color: #333;
    color: white;
  }
  

  .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.5);
    }
    .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 50%;
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }
    .close:hover, .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
</style>