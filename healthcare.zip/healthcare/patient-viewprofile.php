<?php 

include('include/patientsidebar.php');
include('include/header.php'); 
include('dbconnection.php'); 
session_start();

// Check if the user is logged in
if (!isset($_SESSION['patientID'])) {
    echo '<script>alert("You are not logged in. Redirecting to login page."); window.location.href = "patientlogin.php";</script>';
    exit();
}

// Fetch the patient's details
$patientId = $_SESSION['patientID']; // Correct session variable for patientID

$query = "SELECT wallet, fullname, email, gender, blood, address FROM patient WHERE patientID = ?";
$stmt = $conn->prepare($query);
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}
$stmt->bind_param("i", $patientId); // Correct parameter binding with $patientId
$stmt->execute();
$stmt->bind_result($wallet, $fullname, $email, $gender, $blood, $address); // Bind the result to the correct variables
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Profile</title>
    <style>
        /* Add some basic styles for the container */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        p {
            font-size: 16px;
            margin: 10px 0;
        }

        strong {
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Patient Profile</h1>
        <p><strong>Wallet Address:</strong> <?php echo htmlspecialchars($wallet); ?></p>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($fullname); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
        <p><strong>Gender:</strong> <?php echo htmlspecialchars($gender); ?></p>
        <p><strong>Blood Type:</strong> <?php echo htmlspecialchars($blood); ?></p>
        <p><strong>Address:</strong> <?php echo htmlspecialchars($address); ?></p>
    </div>
</body>
</html>
