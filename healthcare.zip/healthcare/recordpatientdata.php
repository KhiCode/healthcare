<?php
include('dbconnection.php');

if (isset($_POST['record'])) {
    $id = $_POST['id'];
    $diagnosis = $_POST['diagnosis'];
    $prescription = $_POST['prescription'];

    $stmt = $conn->prepare("INSERT INTO medical_records (patient_id, diagnosis, prescription) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $id, $diagnosis, $prescription);

    if ($stmt->execute()) {
        echo '<script>alert("Record saved successfully."); window.location.href = "managepatients.php";</script>';
    } else {
        echo '<script>alert("Error saving record."); window.location.href = "managepatients.php";</script>';
    }

    $stmt->close();
    $conn->close();
}
?>