<?php 
include('include/sidebar.php');
include('include/patientregstyle.php'); 
include('include/header.php'); 
?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Patient Registration Form</h2>
    <form id="registrationForm" action="patientregconn.php" method="POST">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="walletAddress" class="form-label">Wallet Public Address</label>
                <input type="text" class="form-control" id="walletAddress" name="wallet" required readonly>
            </div>
            <div class="col-md-6">
                <label for="fullName" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="fullName" name="fullName" required>
            </div>
            <div class="col-md-6">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" class="form-control" id="dob" name="dob" required>
            </div>
            <div class="col-md-6">
                <label for="gender" class="form-label">Gender</label>
                <select class="form-select" id="gender" name="gender" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="specialization" class="form-label">Blood Group</label>
                <select class="form-select" id="specialization" name="specialization" required>
                    <option value="A+">A+</option>
                    <option value="O">O</option>
                    <option value="B+">B+</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="address" class="form-label">Home Address</label>
                <input type="text" class="form-control" id="address" name="address" required>
            </div>
            <div class="col-md-6">
                <label for="hhNumber" class="form-label">HH Number</label>
                <input type="text" class="form-control" id="hhNumber" name="hhNumber" required>
            </div>
            <div class="col-md-6">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="col-md-6">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="col-md-6">
                <label for="confirmPassword" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
            </div>
        </div>
        <div class="mt-4 text-center">
            <button type="submit" class="btn btn-primary">Register</button>
        </div>
    </form>
</div>

<!-- MetaMask Integration -->
<script src="https://cdn.jsdelivr.net/npm/web3/dist/web3.min.js"></script>
<script>
    // Check if MetaMask is installed
    if (typeof window.ethereum !== 'undefined') {
        const web3 = new Web3(window.ethereum);

        // Request MetaMask account access
        ethereum.enable().then(accounts => {
            console.log('Connected Wallet:', accounts[0]);
            document.getElementById('walletAddress').value = accounts[0]; // Assign wallet address to input field
        }).catch(error => {
            console.error('MetaMask access denied:', error);
        });
    } else {
        alert('MetaMask is not installed. Please install MetaMask and try again.');
    }
</script>

<?php 
include('include/footer.php');
?> 
